from argostranslate import package

package.update_package_index()
available = package.get_available_packages()
pkg = next(p for p in available if p.from_code == "en" and p.to_code == "pt")
package.install_from_path(pkg.download())

print("OK: pacote en->pt instalado")
