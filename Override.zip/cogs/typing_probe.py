# cogs/typing_probe.py

import time
import logging
import discord
from discord.ext import commands

log = logging.getLogger("typing_probe")


class TypingProbe(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last = {}   # (channel_id, user_id) -> ts
        self._count = {}  # (channel_id, user_id) -> count

    @commands.Cog.listener()
    async def on_typing(self, channel: discord.abc.Messageable, user: discord.User, when):
        # ignora bots
        if getattr(user, "bot", False):
            return

        now = time.time()
        ch_id = getattr(channel, "id", None)
        key = (ch_id, user.id)

        last = self._last.get(key, 0.0)
        dt = now - last if last else 0.0

        self._last[key] = now
        self._count[key] = self._count.get(key, 0) + 1
        count = self._count[key]

        guild_name = "DM"
        ch_name = "DM"
        if isinstance(channel, discord.TextChannel):
            guild_name = channel.guild.name
            ch_name = f"#{channel.name}"
        elif isinstance(channel, discord.Thread):
            guild_name = channel.guild.name
            ch_name = f"(thread){channel.name}"

        msg = (
            f"[TYPING] user={user} ({user.id}) "
            f"guild={guild_name} channel={ch_name} ({ch_id}) "
            f"count={count} dt={dt:.2f}s"
        )

        log.info(msg)
        print(msg)


async def setup(bot: commands.Bot):
    await bot.add_cog(TypingProbe(bot))
