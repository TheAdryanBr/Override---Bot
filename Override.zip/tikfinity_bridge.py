import asyncio
import json
import os
import aiohttp
import websockets

TIKFINITY_WS = os.getenv("TIKFINITY_WS", "ws://localhost:21213/")
SERVER_WEBHOOK = os.getenv("SERVER_WEBHOOK", "http://SEU_SERVIDOR:PORTA/webhook/tiktok")
SECRET = os.getenv("TIKFINITY_WEBHOOK_SECRET", "").strip() or None

# username do seu canal (pra live_url)
DEFAULT_USERNAME = os.getenv("TIKTOK_USERNAME", "").strip().lstrip("@") or None


def pick(d, *keys):
    for k in keys:
        if isinstance(d, dict) and k in d and d[k] not in (None, "", [], {}):
            return d[k]
    return None


def normalize_room_info(data: dict):
    """
    TikFinity diz que a estrutura do data segue TikTok-Live-Connector. :contentReference[oaicite:4]{index=4}
    No Live-Connector, roomInfo pode vir no connect se habilitado. :contentReference[oaicite:5]{index=5}
    Então tentamos achar roomInfo em lugares comuns.
    """
    room = pick(data, "roomInfo", "room_info", "roominfo") or {}
    # às vezes vem “aninhado” ou com outro nome:
    if not room and isinstance(data.get("data"), dict):
        room = pick(data["data"], "roomInfo", "room_info", "roominfo") or {}
    return room if isinstance(room, dict) else {}


def extract_info(msg: dict):
    event = pick(msg, "event")
    data = pick(msg, "data") if isinstance(pick(msg, "data"), dict) else {}

    room = normalize_room_info(data)

    username = pick(data, "uniqueId", "unique_id", "username", "user") or DEFAULT_USERNAME
    if isinstance(username, str):
        username = username.lstrip("@").strip()
    else:
        username = DEFAULT_USERNAME

    title = pick(room, "title") or pick(data, "title")
    game = pick(room, "category", "game", "gameTag") or pick(data, "category", "game")
    thumb = pick(room, "coverUrl", "cover_url", "cover") or pick(data, "coverUrl", "cover_url", "cover")

    if username:
        live_url = f"https://www.tiktok.com/@{username}/live"
    else:
        live_url = None

    return event, username, title, game, thumb, live_url


async def post_live_info(session: aiohttp.ClientSession, payload: dict):
    headers = {}
    if SECRET:
        headers["X-Webhook-Token"] = SECRET

    async with session.post(SERVER_WEBHOOK, json=payload, headers=headers, timeout=10) as r:
        await r.text()  # só pra consumir
        return r.status


async def main():
    last_sent = None

    async with aiohttp.ClientSession() as session:
        while True:
            try:
                async with websockets.connect(TIKFINITY_WS, ping_interval=20, ping_timeout=20) as ws:
                    print("[bridge] conectado no TikFinity WS")
                    async for raw in ws:
                        try:
                            msg = json.loads(raw)
                        except Exception:
                            continue

                        event, username, title, game, thumb, live_url = extract_info(msg)

                        # Só manda quando tiver pelo menos algo útil
                        if not username:
                            continue

                        # Heurística: se aparecer título/jogo/thumb em algum momento, dispare live_info
                        if not any([title, game, thumb]):
                            continue

                        payload = {
                            "event": "live_info",
                            "username": username,
                            "title": title,
                            "game": game,
                            "thumb": thumb,
                            "live_url": live_url,
                        }

                        # evita spam se ficar repetindo o mesmo
                        key = json.dumps(payload, sort_keys=True, ensure_ascii=False)
                        if key == last_sent:
                            continue
                        last_sent = key

                        status = await post_live_info(session, payload)
                        print(f"[bridge] live_info enviado ({status})")

            except Exception as e:
                print(f"[bridge] reconectando em 3s… ({e})")
                await asyncio.sleep(3)


if __name__ == "__main__":
    asyncio.run(main())
